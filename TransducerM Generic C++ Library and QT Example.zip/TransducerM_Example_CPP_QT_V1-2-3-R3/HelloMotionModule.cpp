/**
 * HelloMotionModule.cpp
 * @author COPYRIGHT(c) 2018 SYD Dynamics ApS
 * @see    HelloMotionModule.h for more descriptions.
 */
#include "HelloMotionModule.h"
#include "ui_HelloMotionModule.h"


// Motion Module Interface:
EasyObjectDictionary eOD;
EasyProfile          eP(&eOD);


HelloMotionModule::HelloMotionModule(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::HelloMotionModule)
{
    ui->setupUi(this);
    ui->groupBox_Example->setEnabled(false);
    serial = new QSerialPort;
}

HelloMotionModule::~HelloMotionModule()
{
    if(serial->isOpen())serial->close();
    delete ui;
}





//----------------------------------------------------------------------------------------
/**
 * @version [This Example applys to all TransducerM models]
 */
// Serial Send Request Example                                 // Note: sending a request to the Module Module is only required to feach data which is not set
                                                               //       to automatic sent. Such setting is done via the IMU Assistant.
void HelloMotionModule::on_pushButton_TX_Request_RPY_clicked()
{
    uint16 toId = ui->spinBox_TX_Request_ShortId->value();     // Step 1: Get the destination device ID to which the request is sent
    //uint16 toId = EP_ID_BROADCAST_;                          //       You can also choose to boardcast the request without specifying the target device ID
    if(EP_SUCC_ == eOD.Write_Ep_Request(toId, EP_CMD_RPY_)){   // Step 2: Write the device ID into the data structure (i.e. the request itself) pending to be sent
        EP_ID_TYPE_  txToId;
        char*        txPkgData;
        int          txPkgSize;
        EP_CMD_TYPE_ txCmd = EP_CMD_REQUEST_;                  // Step 3: Define what type of data we are requesting for. (in this example, we are requesting Roll-Pitch-Yaw readings.
        if(EP_SUCC_ == eP.On_SendPkg(txCmd, &txToId, &txPkgData, &txPkgSize)){ // Step 4: create a package out of the data structure (i.e. the payload) to be sent
            serial->write(QByteArray(txPkgData, txPkgSize));   // Step 5:  Send the package via Serial Port
            statusBar()->showMessage(tr("RPY Request Sent to %1 Successfully").arg(toId));
        }
    }
}

/**
 * @version [This Example applys to all TransducerM models]
 */
void HelloMotionModule::on_pushButton_TX_Request_Quaternion_clicked()
{
    uint16 toId = ui->spinBox_TX_Request_ShortId->value();      // Step 1: Get the destination device ID to which the request is sent
    //uint16 toId = EP_ID_BROADCAST_;                           //       You can also choose to boardcast the request without specifying the target device ID
    if(EP_SUCC_ == eOD.Write_Ep_Request(toId, EP_CMD_Q_S1_E_)){ // Step 2: Write the device ID into the data structure (i.e. the request itself) pending to be sent
        EP_ID_TYPE_  txToId;
        char*        txPkgData;
        int          txPkgSize;
        EP_CMD_TYPE_ txCmd = EP_CMD_REQUEST_;                   // Step 3: Define what type of data we are requesting for. (in this example, we are requesting Quaternion readings.
        if(EP_SUCC_ == eP.On_SendPkg(txCmd, &txToId, &txPkgData, &txPkgSize)){ // Step 4: create a package out of the data structure (i.e. the payload) to be sent
            serial->write(QByteArray(txPkgData, txPkgSize));    // Step 5:  Send the package via Serial Port
            statusBar()->showMessage(tr("RPY Request Sent to %1 Successfully").arg(toId));
        }
    }
}
// Serial Send Request Example
//----------------------------------------------------------------------------------------






//----------------------------------------------------------------------------------------
// Serial Receive Data Example
/// @version  [This Example applys to all TransducerM models]
void HelloMotionModule::on_SerialRX(){
    QByteArray rxByteArray = serial->readAll();                // Step 1: read the received data buffer of the Serial Port
    char*  rxData = rxByteArray.data();                        //         and then convert it to data types acceptable by the
    int    rxSize = rxByteArray.size();                        //         Communication Abstraction Layer (CAL).

    Serial_ISR(rxData, rxSize);
    Serial_ISR(0, 0);                                          //         Flush packages in the ring buffer.
    Serial_ISR(0, 0);
    Serial_ISR(0, 0);
    Serial_ISR(0, 0);
    Serial_ISR(0, 0);
}

void HelloMotionModule::Serial_ISR(char* rxData, int rxSize){
    Ep_Header header;
    if(EP_SUCC_ == eP.On_RecvPkg(rxData, rxSize, &header)){    // Step 2: Tell the CAL that new data has arrived.
                                                               //         It does not matter if the new data only contains a fraction
                                                               //         of a complete package, nor does it matter if the data is broken
                                                               //         during the transmission. On_RecvPkg() will only return EP_SUCC_
                                                               //         when a complete and correct package has arrived.

        // Example Reading of the Short ID of the device who send the data:
        uint32 fromId = header.fromId;                         // Step 3.1:  Now we are able to read the received payload data.
                                                               //            header.fromId tells us from which Motion Module the data comes.

        (void)fromId;                                          //            Supress "parameter unused" complier warning


        switch (header.cmd) {                                  // Step 3.2: header.cmd tells what kind of data is inside the payload.
        case EP_CMD_ACK_:{                                     //           We can use a switch() as demonstrated here to do different
            Ep_Ack ep_Ack;                                     //           tasks for different types of data.
            if(EP_SUCC_ == eOD.Read_Ep_Ack(&ep_Ack)){

            }
        }break;
        case EP_CMD_STATUS_:{
            Ep_Status ep_Status;
            if(EP_SUCC_ == eOD.Read_Ep_Status(&ep_Status)){
                int qos = ep_Status.sysState.bits.qos;        //  This is how you read the Quality-of-Service
                                                              //  For definition of the digits, please refer to the
                                                              //  defintion of 'Ep_Status_SysState' in EasyObjectDictionary.h
                (void)qos;
            }
        }break;
        case EP_CMD_Raw_GYRO_ACC_MAG_:{
            Ep_Raw_GyroAccMag ep_Raw_GyroAccMag;
            if(EP_SUCC_ == eOD.Read_Ep_Raw_GyroAccMag(&ep_Raw_GyroAccMag)){

            }
        }break;
        case EP_CMD_Q_S1_S_:{
            Ep_Q_s1_s ep_Q_s1_s;
            if(EP_SUCC_ == eOD.Read_Ep_Q_s1_s(&ep_Q_s1_s)){

            }
        }break;
        case EP_CMD_Q_S1_E_:{
            Ep_Q_s1_e ep_Q_s1_e;
            if(EP_SUCC_ == eOD.Read_Ep_Q_s1_e(&ep_Q_s1_e)){ // Step 3.3: If we decided that the received Quaternion should be used,
                                                            //           Here is an example of how to access the Quaternion data.
                float q1 = ep_Q_s1_e.q[0];
                float q2 = ep_Q_s1_e.q[1];
                float q3 = ep_Q_s1_e.q[2];
                float q4 = ep_Q_s1_e.q[3];
                uint32 timeStamp = ep_Q_s1_e.timeStamp;     //           TimeStamp indicates the time point (since the Module has been powered on),
                                                            //           when this particular set of Quaternion was calculated. (Unit: uS)
                                                            //           Note that overflow will occure when the uint32 type reaches its maximum value.
                uint32 deviceId  = ep_Q_s1_e.header.fromId; //           The ID indicates the device Short ID telling which Motion Module the data comes from.

                // Display the data on GUI:
                qDebug()<<"Q1="<<q1<<"  Q2="<<q2<<"  Q3="<<q3<<"  Q4="<<q4<<"  TimeStamp="<<timeStamp<<" Device Short ID"<<deviceId;
                ui->doubleSpinBox_RX_Q1->setValue( q1 );
                ui->doubleSpinBox_RX_Q2->setValue( q2 );
                ui->doubleSpinBox_RX_Q3->setValue( q3 );
                ui->doubleSpinBox_RX_Q4->setValue( q4 );
                ui->label_RX_Q_TimeStamp->setText(tr("%1").arg( timeStamp ));
                ui->label_RX_Q_ID->setText(tr("%1").arg(deviceId));
            }
        }break;
        case EP_CMD_EULER_S1_S_:{
            Ep_Euler_s1_s ep_Euler_s1_s;
            if(EP_SUCC_ == eOD.Read_Ep_Euler_s1_s(&ep_Euler_s1_s)){

            }
        }break;
        case EP_CMD_EULER_S1_E_:{
            Ep_Euler_s1_e ep_Euler_s1_e;
            if(EP_SUCC_ == eOD.Read_Ep_Euler_s1_e(&ep_Euler_s1_e)){

            }
        }break;
        case EP_CMD_RPY_:{
            Ep_RPY ep_RPY;
            if(EP_SUCC_ == eOD.Read_Ep_RPY(&ep_RPY)){     //           Another Example reading of the received Roll Pitch and Yaw
                float roll  = ep_RPY.roll;
                float pitch = ep_RPY.pitch;
                float yaw   = ep_RPY.yaw;
                uint32 timeStamp = ep_RPY.timeStamp;      //           TimeStamp indicates the time point (since the Module has been powered on),
                                                          //           when this particular set of Roll-Pitch-Yaw was calculated. (Unit: uS)
                                                          //           Note that overflow will occure when the uint32 type reaches its maximum value.
                uint32 deviceId  = ep_RPY.header.fromId;  //           The ID indicates from wich IMU Module the data comes from.


                // Display the data on GUI:
                qDebug()<<"Roll="<<roll<<"  Pitch="<<pitch<<"  Yaw="<<yaw<<"  TimeStamp="<<timeStamp<<" Device Short ID"<<deviceId;
                ui->doubleSpinBox_RX_Roll->setValue( roll );
                ui->doubleSpinBox_RX_Pitch->setValue( pitch );
                ui->doubleSpinBox_RX_Yaw->setValue( yaw );
                ui->label_RX_RPY_TimeStamp->setText(tr("%1").arg( timeStamp ));
                ui->label_RX_RPY_ID->setText(tr("%1").arg(deviceId));
            }
        }break;
        case EP_CMD_GRAVITY_:{
            Ep_Gravity ep_Gravity;
            if(EP_SUCC_ == eOD.Read_Ep_Gravity(&ep_Gravity)){

            }
        }break;
        }

    }
}
// Serial Receive Data Example
//----------------------------------------------------------------------------------------













//----------------------------------------------------------------------------------------
// Trivial GUI utility functions, Not important
void HelloMotionModule::on_pushButton_Serialport_Open_clicked()
{
    QString portName = ui->lineEdit_Serialport_Name->text();
    serial->setPortName(portName);
    serial->setBaudRate(QSerialPort::Baud115200);
    serial->setDataBits(QSerialPort::Data8);
    serial->setParity(QSerialPort::NoParity);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setFlowControl(QSerialPort::NoFlowControl);
    if(serial->open(QIODevice::ReadWrite)){
       QObject::connect(serial, SIGNAL(readyRead()), this, SLOT(on_SerialRX()));
       ui->pushButton_Serialport_Open->setEnabled(false);
       ui->lineEdit_Serialport_Name->setEnabled(false);
       ui->groupBox_Example->setEnabled(true);
       statusBar()->showMessage(portName + tr(" opened successfully"));
    }
    else{
       statusBar()->showMessage(portName + tr(" failed to open"));
    }
}

void HelloMotionModule::on_pushButton_UseBroadcastId_clicked()
{
    ui->spinBox_TX_Request_ShortId->setValue(EP_ID_BROADCAST_);
    ui->pushButton_UseBroadcastId->setEnabled(false);
}

void HelloMotionModule::on_spinBox_TX_Request_ShortId_valueChanged(int arg1)
{
    Q_UNUSED(arg1);
    ui->pushButton_UseBroadcastId->setEnabled(true);
}
// Trivial GUI utility functions, Not important
//----------------------------------------------------------------------------------------

